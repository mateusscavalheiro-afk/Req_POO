@SuppressWarnings("all")

public class main {
    public static void main(String[] args) {
        motoreletrico m1 = new motoreletrico("WEG", 850, 0);
        m1.detalhes_motor();
    }
}
