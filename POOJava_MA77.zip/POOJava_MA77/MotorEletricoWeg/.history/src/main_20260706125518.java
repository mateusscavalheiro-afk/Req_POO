@SuppressWarnings("all")

public class main {
    public static void main(String[] args) {
        motoreletrico m1 = new motoreletrico("W16", 850, 0);
        motoreletrico m2 = new motoreletrico("W22", 150, 19);
        
    }
}
