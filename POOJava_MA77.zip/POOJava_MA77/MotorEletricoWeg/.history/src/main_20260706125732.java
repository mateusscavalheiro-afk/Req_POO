@SuppressWarnings("all")

public class main {
    public static void main(String[] args) {
        motoreletrico m1 = new motoreletrico("W16", 850, 8);
        motoreletrico m2 = new motoreletrico("W22", 150, 19);
        
        // TESTE DE VALIDAÇÃO: CORRENTE INVÁLIDA
        m1.detalhes_motor();

        // DEMONSTRAÇÃO DA FICHA DE UM MOTOR
        m2.detalhes_motor();
    }
}
