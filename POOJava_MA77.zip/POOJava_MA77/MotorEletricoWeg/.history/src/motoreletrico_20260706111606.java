public class motoreletrico {

    // ATRIBUTOS DA CLASSE MOTOR ELÉTRICO
    private String modelo;
    private double potenciacv;
    private double corr_nominal;
    private double velocidadeRPM;
    private String status;
    private String alarmes;
    
    // MÉTODO CONSTRUTOR
    public motoreletrico(String modelo, double potenciacv, double corr_nominal) {
        this.modelo = modelo;
        this.potenciacv = potenciacv;
        this.corr_nominal = corr_nominal;
        this.velocidadeRPM = 1750;
        this.status = "Desligado";
        this.alarmes = "Nenhum";
    }

    // MÉTODOS GET & SET
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPotenciacv() {
        return potenciacv;
    }

    public void setPotenciacv(double potenciacv) {
        this.potenciacv = potenciacv;
    }

    public double getCorr_nominal() {
        return corr_nominal;
    }

    public void setCorr_nominal(double corr_nominal) {
        if (corr_nominal <= 0) {
            System.out.println("xx-- Erro! O motor não deve operar em corrente inválida! --xx");
            System.out.println("##-- Insira uma corrente maior que 0 --##");
        return;
        } 
        this.corr_nominal = corr_nominal;
        }

    public double getVelocidadeRPM() {
        return velocidadeRPM;
    }

    public void setVelocidadeRPM(double velocidadeRPM) {
        this.velocidadeRPM = velocidadeRPM;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAlarmes() {
        return alarmes;
    }

    public void setAlarmes(String alarmes) {
        this.alarmes = alarmes;
    }

    // MÉTODOS PERSONALIZADOS
    public double calculo_consumo(){
        return potenciacv * 0.736; // CV -> kW
    }
    
    public void registrar_alarme(String alarme){
        if (this.alarmes.equals("Nenhum")) {
            this.alarmes = alarme;
        } else {
            this.alarmes += ", " + alarme;
        }
    }
    
    public void mudar_status(String novoStatus){
        this.status = novoStatus;
    }

    
}
