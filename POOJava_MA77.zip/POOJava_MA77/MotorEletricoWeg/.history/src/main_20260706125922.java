@SuppressWarnings("all")

public class main {
    public static void main(String[] args) {
        motoreletrico m1 = new motoreletrico("W16", 850, 8);
        motoreletrico m2 = new motoreletrico("W22", 750, 19);
        
        // TESTE DE VALIDAÇÃO: CORRENTE INVÁLIDA
        m1.setCorr_nominal(-2);

        // REGISTRAR ALARME
        m1.registrar_alarme("Subcarga Detectada!");
        m1.registrar_alarme("Aumento de Temperatura Crítica Detectada!");

        // DEMONSTRAÇÃO DA FICHA DE UM MOTOR
        m2.detalhes_motor();
    }
}
