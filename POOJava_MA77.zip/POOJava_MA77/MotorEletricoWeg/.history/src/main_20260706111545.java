public class main {
    public static void main(String[] args) {
        motoreletrico m1 = new motoreletrico("WEG", 850, 12);
        
    }
}
